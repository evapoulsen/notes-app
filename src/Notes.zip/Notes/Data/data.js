export const data = [
    { id: 1, body: `a` },
    { id: 2, body: `b` },
    { id: 3, body: `c` },
    { id: 4, body: `d` },
    { id: 5, body: `e` },
]
